package com.example.ms_auth.security;

import java.security.Key;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtUtil {
    private final Key key;
    private final long EXPIRATION_MS = 1000 * 60 * 60;
    private final long REFRESH_EXPIRATION_MS = 1000 * 60 * 60 * 24;

    public JwtUtil(@Value("${jwt.secret}") String secret) { this.key = Keys.hmacShaKeyFor(secret.getBytes()); }

    public String generarToken(String username, String role) {
        return Jwts.builder().setSubject(username).claim("role", role).setIssuedAt(new Date()).setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_MS)).signWith(key, SignatureAlgorithm.HS256).compact();
    }
    public String generarRefreshToken(String username) {
        return Jwts.builder().setSubject(username).claim("type", "refresh").setIssuedAt(new Date()).setExpiration(new Date(System.currentTimeMillis() + REFRESH_EXPIRATION_MS)).signWith(key, SignatureAlgorithm.HS256).compact();
    }
    public boolean esValido(String token) { try { return !getClaims(token).getExpiration().before(new Date()); } catch (Exception e) { return false; } }
    public String obtenerUsuario(String token) { return getClaims(token).getSubject(); }
    public boolean esRefreshToken(String token) { return "refresh".equals(getClaims(token).get("type")); }
    private Claims getClaims(String token) { return Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token).getBody(); }
}
